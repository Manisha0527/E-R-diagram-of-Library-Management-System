package com.example.model;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class LoanDTO {
	private int lid;
	private int bid;
	private int mid;
	private String rdate;
	private String ldate;

}
