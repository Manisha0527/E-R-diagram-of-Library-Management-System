package com.example.model;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class MemberDTO {
	private int mid;
	private String name;
	private String address;
	private String mtype;
	private String mdate;
	private String expdate;
	
}
