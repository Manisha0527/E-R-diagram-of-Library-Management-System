package com.example.model;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class LibrarianDTO {
	private int lid;
	private String name;
	private int eno;
	private long cno;

}
