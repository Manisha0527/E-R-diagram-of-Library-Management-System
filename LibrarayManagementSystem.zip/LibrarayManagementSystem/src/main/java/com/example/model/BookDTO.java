package com.example.model;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class BookDTO {
	private int bid;
	private String title;
	private String author;
	private int price;
	private int availablel;
	

}
