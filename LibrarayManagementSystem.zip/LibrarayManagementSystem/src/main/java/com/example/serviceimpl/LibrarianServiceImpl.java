package com.example.serviceimpl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;

import com.example.Utitity.LibrarianConverter;
import com.example.entities.Librarian;
import com.example.model.LibrarianDTO;
import com.example.repository.LibrarianRepository;
import com.example.service.LibrarianService;

@Service
public class LibrarianServiceImpl implements LibrarianService{
	@Autowired
public LibrarianRepository librarianRepository;
	@Autowired
	LibrarianConverter libraryConverter;
	@Override
	public LibrarianDTO saveBookInfo(Librarian librarian) {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public List<LibrarianDTO> getAllLibrarianInfo() {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public LibrarianDTO getByLibrarianId(int lid) {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public String deleteLibrarianInfoById(int lid) {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public LibrarianDTO updateLibrarianInfo(int lid, Librarian librarian) {
		// TODO Auto-generated method stub
		return null;
	}
}