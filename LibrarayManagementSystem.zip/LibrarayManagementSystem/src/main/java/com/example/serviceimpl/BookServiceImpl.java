package com.example.serviceimpl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;

import com.example.Utitity.BookConverter;
import com.example.entities.Book;
import com.example.model.BookDTO;
import com.example.repository.BookRepository;
import com.example.service.BookService;

@Service
public class BookServiceImpl implements BookService{
	@Autowired
public BookRepository bookRepository;
	@Autowired
	BookConverter bookConverter;
	@Override
	public BookDTO saveBookInfo(Book book) {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public List<BookDTO> getAllBookInfo() {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public BookDTO getByBookId(int bid) {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public String deleteBookInfoById(int bid) {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public BookDTO updateBookInfo(int bid, Book book) {
		// TODO Auto-generated method stub
		return null;
	}
}
	