package com.example.serviceimpl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;

import com.example.Utitity.MemberConverter;
import com.example.entities.Member;
import com.example.model.MemberDTO;
import com.example.repository.MemberRepository;
import com.example.service.MemberService;

@Service
public class MemberServiceImpl implements MemberService{
	@Autowired
public MemberRepository memberRepository;
	@Autowired
	MemberConverter memberConverter;
	@Override
	public MemberDTO saveMemberInfo(Member member) {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public List<MemberDTO> getAllMemberInfo() {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public MemberDTO getByMemberId(int mid) {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public String deleteMemberInfoById(int mid) {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public MemberDTO updateMemberInfo(int mid, Member member) {
		// TODO Auto-generated method stub
		return null;
	}
}